require 'test_helper'

class PersonsRegisterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
