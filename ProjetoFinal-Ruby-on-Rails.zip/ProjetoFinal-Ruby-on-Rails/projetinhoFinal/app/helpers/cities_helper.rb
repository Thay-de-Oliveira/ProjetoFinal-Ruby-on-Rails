module CitiesHelper

    def format_date_br(us_date)
        us_date.strftime("%d/%m/%Y")
    end

end
