class PersonsRegister < ApplicationRecord
end
