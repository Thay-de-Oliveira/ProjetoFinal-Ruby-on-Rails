class Service < ApplicationRecord
    # belongs_to = a Classe PERTENCE a próxima classe add 
    belongs_to :events_form
end
